﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Applications.Applications.Accounting
{
    public partial class Accounting_Template : HAWK_Template_2
    {
        public Accounting_Template()
        {
            InitializeComponent();
        }
    }
}
