﻿    partial class HAWK_Template_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HAWK_Template_2));
            this.button_ChangeObject = new System.Windows.Forms.Button();
            this.button_DisplaySelectedObject = new System.Windows.Forms.Button();
            this.button_ListObjects = new System.Windows.Forms.Button();
            this.button_List = new System.Windows.Forms.Button();
            this.button_DisplaySelected = new System.Windows.Forms.Button();
            this.button_Change = new System.Windows.Forms.Button();
            this._panel2_LeftControlPanel.SuspendLayout();
            this.panel_TopPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RightLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LeftLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // _panel2_LeftControlPanel
            // 
            this._panel2_LeftControlPanel.Controls.Add(this.button_Change);
            this._panel2_LeftControlPanel.Controls.Add(this.button_DisplaySelected);
            this._panel2_LeftControlPanel.Controls.Add(this.button_List);
            this._panel2_LeftControlPanel.Controls.SetChildIndex(this.button_Return, 0);
            this._panel2_LeftControlPanel.Controls.SetChildIndex(this.button_SearchData, 0);
            this._panel2_LeftControlPanel.Controls.SetChildIndex(this.button_List, 0);
            this._panel2_LeftControlPanel.Controls.SetChildIndex(this.button_DisplaySelected, 0);
            this._panel2_LeftControlPanel.Controls.SetChildIndex(this.button_Change, 0);
            // 
            // label_UserID
            // 
            this.label_UserID.Location = new System.Drawing.Point(874, 102);
            this.label_UserID.Visible = true;
            // 
            // label_UserPre
            // 
            this.label_UserPre.Location = new System.Drawing.Point(836, 102);
            this.label_UserPre.Visible = true;
            // 
            // label_UserName
            // 
            this.label_UserName.Location = new System.Drawing.Point(915, 102);
            this.label_UserName.Visible = true;
            // 
            // label_Connector
            // 
            this.label_Connector.Location = new System.Drawing.Point(899, 102);
            // 
            // pictureBox_RightLogo
            // 
            this.pictureBox_RightLogo.Size = new System.Drawing.Size(926, 130);
            // 
            // pictureBox_LeftLogo
            // 
            this.pictureBox_LeftLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_LeftLogo.Image")));
            // 
            // button_ChangeObject
            // 
            this.button_ChangeObject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(144)))), ((int)(((byte)(255)))));
            this.button_ChangeObject.Location = new System.Drawing.Point(0, 0);
            this.button_ChangeObject.Name = "button_ChangeObject";
            this.button_ChangeObject.Size = new System.Drawing.Size(75, 23);
            this.button_ChangeObject.TabIndex = 0;
            this.button_ChangeObject.UseVisualStyleBackColor = false;
            // 
            // button_DisplaySelectedObject
            // 
            this.button_DisplaySelectedObject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(155)))), ((int)(((byte)(255)))));
            this.button_DisplaySelectedObject.Location = new System.Drawing.Point(0, 0);
            this.button_DisplaySelectedObject.Name = "button_DisplaySelectedObject";
            this.button_DisplaySelectedObject.Size = new System.Drawing.Size(75, 23);
            this.button_DisplaySelectedObject.TabIndex = 0;
            this.button_DisplaySelectedObject.UseVisualStyleBackColor = false;
            // 
            // button_ListObjects
            // 
            this.button_ListObjects.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(146)))), ((int)(((byte)(255)))));
            this.button_ListObjects.Location = new System.Drawing.Point(0, 0);
            this.button_ListObjects.Name = "button_ListObjects";
            this.button_ListObjects.Size = new System.Drawing.Size(75, 23);
            this.button_ListObjects.TabIndex = 0;
            this.button_ListObjects.UseVisualStyleBackColor = false;
            // 
            // button_List
            // 
            this.button_List.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_List.Location = new System.Drawing.Point(22, 195);
            this.button_List.Name = "button_List";
            this.button_List.Size = new System.Drawing.Size(110, 65);
            this.button_List.TabIndex = 2;
            this.button_List.Text = "List Objects";
            this.button_List.UseVisualStyleBackColor = false;
            // 
            // button_DisplaySelected
            // 
            this.button_DisplaySelected.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button_DisplaySelected.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DisplaySelected.Location = new System.Drawing.Point(25, 274);
            this.button_DisplaySelected.Name = "button_DisplaySelected";
            this.button_DisplaySelected.Size = new System.Drawing.Size(110, 66);
            this.button_DisplaySelected.TabIndex = 3;
            this.button_DisplaySelected.Text = "Display Selected Object";
            this.button_DisplaySelected.UseVisualStyleBackColor = false;
            // 
            // button_Change
            // 
            this.button_Change.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button_Change.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Change.Location = new System.Drawing.Point(25, 357);
            this.button_Change.Name = "button_Change";
            this.button_Change.Size = new System.Drawing.Size(110, 66);
            this.button_Change.TabIndex = 4;
            this.button_Change.Text = "Change / Create Object";
            this.button_Change.UseVisualStyleBackColor = false;
            // 
            // HAWK_Template_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1178, 736);
            this.Name = "HAWK_Template_2";
            this.Text = "HAWK_Template_2";
            this._panel2_LeftControlPanel.ResumeLayout(false);
            this.panel_TopPanel.ResumeLayout(false);
            this.panel_TopPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RightLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LeftLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected System.Windows.Forms.Label label_Connecter;
        protected System.Windows.Forms.Button button_ListObjects;
        protected System.Windows.Forms.Button button_DisplaySelectedObject;
        protected System.Windows.Forms.Button button_ChangeObject;
        protected System.Windows.Forms.Button button_List;
        protected System.Windows.Forms.Button button_Change;
        protected System.Windows.Forms.Button button_DisplaySelected;
    }
