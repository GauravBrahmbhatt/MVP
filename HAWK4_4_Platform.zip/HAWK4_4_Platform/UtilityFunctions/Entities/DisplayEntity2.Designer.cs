﻿namespace Utilities
{
    partial class DisplayEntity2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_0 = new System.Windows.Forms.Label();
            this.textBox0 = new System.Windows.Forms.TextBox();
            this.button_DisplayEntity = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label_5 = new System.Windows.Forms.Label();
            this.label_9 = new System.Windows.Forms.Label();
            this.label_13 = new System.Windows.Forms.Label();
            this.textBox_Comment = new System.Windows.Forms.TextBox();
            this.label_16 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label_14 = new System.Windows.Forms.Label();
            this.textBox_13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.button_Edit = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label_12 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label_10 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label_8 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label_7 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label_6 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label_4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label_3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label_2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label_1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_TableName = new System.Windows.Forms.TextBox();
            this.textBox_EntityType = new System.Windows.Forms.TextBox();
            this.textBox_EntityName = new System.Windows.Forms.TextBox();
            this.textBox_CMD = new System.Windows.Forms.TextBox();
            this.textBox_DocType = new System.Windows.Forms.TextBox();
            this.button_ResetLabels = new System.Windows.Forms.Button();
            this.button_ResetCMD = new System.Windows.Forms.Button();
            this.label_11 = new System.Windows.Forms.Label();
            this.label_15 = new System.Windows.Forms.Label();
            this._panel2_LeftControlPanel.SuspendLayout();
            this.panel_TopPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RightLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LeftLogo)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label_SubName
            // 
            this.label_SubName.Size = new System.Drawing.Size(157, 28);
            this.label_SubName.Text = "Display Entity";
            // 
            // label_0
            // 
            this.label_0.AutoSize = true;
            this.label_0.Location = new System.Drawing.Point(199, 219);
            this.label_0.Name = "label_0";
            this.label_0.Size = new System.Drawing.Size(73, 13);
            this.label_0.TabIndex = 2;
            this.label_0.Text = "Entity Number";
            // 
            // textBox0
            // 
            this.textBox0.Location = new System.Drawing.Point(301, 219);
            this.textBox0.Name = "textBox0";
            this.textBox0.Size = new System.Drawing.Size(40, 20);
            this.textBox0.TabIndex = 3;
            this.textBox0.Text = "27";
            // 
            // button_DisplayEntity
            // 
            this.button_DisplayEntity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_DisplayEntity.Location = new System.Drawing.Point(562, 171);
            this.button_DisplayEntity.Name = "button_DisplayEntity";
            this.button_DisplayEntity.Size = new System.Drawing.Size(136, 46);
            this.button_DisplayEntity.TabIndex = 4;
            this.button_DisplayEntity.Text = "  Display    Entity";
            this.button_DisplayEntity.UseVisualStyleBackColor = true;
            this.button_DisplayEntity.Click += new System.EventHandler(this.button_DisplayEntity_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label_15);
            this.panel3.Controls.Add(this.label_11);
            this.panel3.Controls.Add(this.label_5);
            this.panel3.Controls.Add(this.label_9);
            this.panel3.Controls.Add(this.label_13);
            this.panel3.Controls.Add(this.textBox_Comment);
            this.panel3.Controls.Add(this.label_16);
            this.panel3.Controls.Add(this.textBox15);
            this.panel3.Controls.Add(this.textBox14);
            this.panel3.Controls.Add(this.label_14);
            this.panel3.Controls.Add(this.textBox_13);
            this.panel3.Controls.Add(this.textBox12);
            this.panel3.Controls.Add(this.textBox11);
            this.panel3.Controls.Add(this.button_Edit);
            this.panel3.Controls.Add(this.textBox10);
            this.panel3.Controls.Add(this.label_12);
            this.panel3.Controls.Add(this.textBox9);
            this.panel3.Controls.Add(this.label_10);
            this.panel3.Controls.Add(this.textBox8);
            this.panel3.Controls.Add(this.label_8);
            this.panel3.Controls.Add(this.textBox7);
            this.panel3.Controls.Add(this.label_7);
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.label_6);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.label_4);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.label_3);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.label_2);
            this.panel3.Location = new System.Drawing.Point(202, 299);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(547, 309);
            this.panel3.TabIndex = 5;
            this.panel3.Visible = false;
            // 
            // label_5
            // 
            this.label_5.AutoSize = true;
            this.label_5.Location = new System.Drawing.Point(72, 79);
            this.label_5.Name = "label_5";
            this.label_5.Size = new System.Drawing.Size(45, 13);
            this.label_5.TabIndex = 30;
            this.label_5.Text = "Address";
            // 
            // label_9
            // 
            this.label_9.AutoSize = true;
            this.label_9.Location = new System.Drawing.Point(76, 144);
            this.label_9.Name = "label_9";
            this.label_9.Size = new System.Drawing.Size(43, 13);
            this.label_9.TabIndex = 29;
            this.label_9.Text = "Country";
            // 
            // label_13
            // 
            this.label_13.AutoSize = true;
            this.label_13.Location = new System.Drawing.Point(78, 216);
            this.label_13.Name = "label_13";
            this.label_13.Size = new System.Drawing.Size(56, 13);
            this.label_13.TabIndex = 28;
            this.label_13.Text = "Addresses";
            // 
            // textBox_Comment
            // 
            this.textBox_Comment.Location = new System.Drawing.Point(167, 277);
            this.textBox_Comment.Name = "textBox_Comment";
            this.textBox_Comment.Size = new System.Drawing.Size(331, 20);
            this.textBox_Comment.TabIndex = 27;
            // 
            // label_16
            // 
            this.label_16.AutoSize = true;
            this.label_16.Location = new System.Drawing.Point(14, 277);
            this.label_16.Name = "label_16";
            this.label_16.Size = new System.Drawing.Size(51, 13);
            this.label_16.TabIndex = 26;
            this.label_16.Text = "Comment";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(303, 241);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(109, 20);
            this.textBox15.TabIndex = 25;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(166, 244);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(116, 20);
            this.textBox14.TabIndex = 24;
            // 
            // label_14
            // 
            this.label_14.AutoSize = true;
            this.label_14.Location = new System.Drawing.Point(10, 244);
            this.label_14.Name = "label_14";
            this.label_14.Size = new System.Drawing.Size(33, 13);
            this.label_14.TabIndex = 23;
            this.label_14.Text = "Other";
            // 
            // textBox_13
            // 
            this.textBox_13.Location = new System.Drawing.Point(303, 212);
            this.textBox_13.Name = "textBox_13";
            this.textBox_13.Size = new System.Drawing.Size(109, 20);
            this.textBox_13.TabIndex = 22;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(169, 212);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(113, 20);
            this.textBox12.TabIndex = 20;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(303, 174);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(109, 20);
            this.textBox11.TabIndex = 19;
            // 
            // button_Edit
            // 
            this.button_Edit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Edit.Location = new System.Drawing.Point(400, 4);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(98, 50);
            this.button_Edit.TabIndex = 18;
            this.button_Edit.Text = "Edit this Entity";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(168, 177);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(114, 20);
            this.textBox10.TabIndex = 17;
            // 
            // label_12
            // 
            this.label_12.AutoSize = true;
            this.label_12.Location = new System.Drawing.Point(6, 215);
            this.label_12.Name = "label_12";
            this.label_12.Size = new System.Drawing.Size(35, 13);
            this.label_12.TabIndex = 16;
            this.label_12.Text = "Email ";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(303, 139);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(105, 20);
            this.textBox9.TabIndex = 15;
            // 
            // label_10
            // 
            this.label_10.AutoSize = true;
            this.label_10.Location = new System.Drawing.Point(6, 175);
            this.label_10.Name = "label_10";
            this.label_10.Size = new System.Drawing.Size(38, 13);
            this.label_10.TabIndex = 14;
            this.label_10.Text = "Phone";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(172, 139);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(110, 20);
            this.textBox8.TabIndex = 13;
            // 
            // label_8
            // 
            this.label_8.AutoSize = true;
            this.label_8.Location = new System.Drawing.Point(2, 143);
            this.label_8.Name = "label_8";
            this.label_8.Size = new System.Drawing.Size(56, 13);
            this.label_8.TabIndex = 12;
            this.label_8.Text = " Zip Code ";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(303, 108);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(105, 20);
            this.textBox7.TabIndex = 11;
            // 
            // label_7
            // 
            this.label_7.AutoSize = true;
            this.label_7.Location = new System.Drawing.Point(71, 115);
            this.label_7.Name = "label_7";
            this.label_7.Size = new System.Drawing.Size(35, 13);
            this.label_7.TabIndex = 10;
            this.label_7.Text = " State";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(168, 109);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(114, 20);
            this.textBox6.TabIndex = 9;
            // 
            // label_6
            // 
            this.label_6.AutoSize = true;
            this.label_6.Location = new System.Drawing.Point(4, 115);
            this.label_6.Name = "label_6";
            this.label_6.Size = new System.Drawing.Size(51, 13);
            this.label_6.TabIndex = 8;
            this.label_6.Text = " City ,      ";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(303, 73);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(105, 20);
            this.textBox5.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(168, 73);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(114, 20);
            this.textBox4.TabIndex = 5;
            // 
            // label_4
            // 
            this.label_4.AutoSize = true;
            this.label_4.Location = new System.Drawing.Point(6, 79);
            this.label_4.Name = "label_4";
            this.label_4.Size = new System.Drawing.Size(45, 13);
            this.label_4.TabIndex = 4;
            this.label_4.Text = "Address";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(168, 46);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(114, 20);
            this.textBox3.TabIndex = 3;
            // 
            // label_3
            // 
            this.label_3.AutoSize = true;
            this.label_3.Location = new System.Drawing.Point(6, 52);
            this.label_3.Name = "label_3";
            this.label_3.Size = new System.Drawing.Size(58, 13);
            this.label_3.TabIndex = 2;
            this.label_3.Text = "Last Name";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(169, 17);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(113, 20);
            this.textBox2.TabIndex = 1;
            // 
            // label_2
            // 
            this.label_2.AutoSize = true;
            this.label_2.Location = new System.Drawing.Point(7, 23);
            this.label_2.Name = "label_2";
            this.label_2.Size = new System.Drawing.Size(57, 13);
            this.label_2.TabIndex = 0;
            this.label_2.Text = "First Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(203, 182);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Select Entity";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(301, 180);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(234, 21);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label_1
            // 
            this.label_1.AutoSize = true;
            this.label_1.Location = new System.Drawing.Point(203, 147);
            this.label_1.Name = "label_1";
            this.label_1.Size = new System.Drawing.Size(72, 13);
            this.label_1.TabIndex = 8;
            this.label_1.Text = "Type of Entity";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "0,   Select Entity",
            "1 ,  Applicant",
            "2 ,  Customers",
            "3 ,  Employees",
            "4 ,  Job_Applicants",
            "5 ,  Suppliers",
            "6 ,  Materials"});
            this.comboBox2.Location = new System.Drawing.Point(302, 146);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(139, 21);
            this.comboBox2.TabIndex = 9;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(347, 222);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "from";
            // 
            // textBox_TableName
            // 
            this.textBox_TableName.Location = new System.Drawing.Point(379, 219);
            this.textBox_TableName.Name = "textBox_TableName";
            this.textBox_TableName.Size = new System.Drawing.Size(121, 20);
            this.textBox_TableName.TabIndex = 11;
            // 
            // textBox_EntityType
            // 
            this.textBox_EntityType.Location = new System.Drawing.Point(458, 146);
            this.textBox_EntityType.Name = "textBox_EntityType";
            this.textBox_EntityType.Size = new System.Drawing.Size(70, 20);
            this.textBox_EntityType.TabIndex = 12;
            // 
            // textBox_EntityName
            // 
            this.textBox_EntityName.Location = new System.Drawing.Point(553, 145);
            this.textBox_EntityName.Name = "textBox_EntityName";
            this.textBox_EntityName.Size = new System.Drawing.Size(145, 20);
            this.textBox_EntityName.TabIndex = 13;
            // 
            // textBox_CMD
            // 
            this.textBox_CMD.Location = new System.Drawing.Point(303, 261);
            this.textBox_CMD.Name = "textBox_CMD";
            this.textBox_CMD.Size = new System.Drawing.Size(395, 20);
            this.textBox_CMD.TabIndex = 14;
            // 
            // textBox_DocType
            // 
            this.textBox_DocType.Location = new System.Drawing.Point(506, 220);
            this.textBox_DocType.Name = "textBox_DocType";
            this.textBox_DocType.Size = new System.Drawing.Size(28, 20);
            this.textBox_DocType.TabIndex = 16;
            // 
            // button_ResetLabels
            // 
            this.button_ResetLabels.Location = new System.Drawing.Point(202, 255);
            this.button_ResetLabels.Name = "button_ResetLabels";
            this.button_ResetLabels.Size = new System.Drawing.Size(75, 23);
            this.button_ResetLabels.TabIndex = 17;
            this.button_ResetLabels.Text = "reset labels";
            this.button_ResetLabels.UseVisualStyleBackColor = true;
            this.button_ResetLabels.Click += new System.EventHandler(this.button_ResetLabels_Click);
            // 
            // button_ResetCMD
            // 
            this.button_ResetCMD.Location = new System.Drawing.Point(595, 226);
            this.button_ResetCMD.Name = "button_ResetCMD";
            this.button_ResetCMD.Size = new System.Drawing.Size(75, 23);
            this.button_ResetCMD.TabIndex = 18;
            this.button_ResetCMD.Text = "reset CMD";
            this.button_ResetCMD.UseVisualStyleBackColor = true;
            // 
            // label_11
            // 
            this.label_11.AutoSize = true;
            this.label_11.Location = new System.Drawing.Point(79, 174);
            this.label_11.Name = "label_11";
            this.label_11.Size = new System.Drawing.Size(38, 13);
            this.label_11.TabIndex = 31;
            this.label_11.Text = "Phone";
            // 
            // label_15
            // 
            this.label_15.AutoSize = true;
            this.label_15.Location = new System.Drawing.Point(81, 244);
            this.label_15.Name = "label_15";
            this.label_15.Size = new System.Drawing.Size(0, 13);
            this.label_15.TabIndex = 32;
            // 
            // DisplayEntity2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1253, 728);
            this.Controls.Add(this.button_ResetCMD);
            this.Controls.Add(this.button_ResetLabels);
            this.Controls.Add(this.textBox_DocType);
            this.Controls.Add(this.textBox_CMD);
            this.Controls.Add(this.textBox_EntityName);
            this.Controls.Add(this.textBox_EntityType);
            this.Controls.Add(this.textBox_TableName);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label_1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button_DisplayEntity);
            this.Controls.Add(this.textBox0);
            this.Controls.Add(this.label_0);
            this.Name = "DisplayEntity2";
            this.Text = "Display Customer";
            this.Controls.SetChildIndex(this._panel2_LeftControlPanel, 0);
            this.Controls.SetChildIndex(this.panel_TopPanel, 0);
            this.Controls.SetChildIndex(this.label_0, 0);
            this.Controls.SetChildIndex(this.textBox0, 0);
            this.Controls.SetChildIndex(this.button_DisplayEntity, 0);
            this.Controls.SetChildIndex(this.panel3, 0);
            this.Controls.SetChildIndex(this.label11, 0);
            this.Controls.SetChildIndex(this.comboBox1, 0);
            this.Controls.SetChildIndex(this.label_1, 0);
            this.Controls.SetChildIndex(this.comboBox2, 0);
            this.Controls.SetChildIndex(this.label12, 0);
            this.Controls.SetChildIndex(this.textBox_TableName, 0);
            this.Controls.SetChildIndex(this.textBox_EntityType, 0);
            this.Controls.SetChildIndex(this.textBox_EntityName, 0);
            this.Controls.SetChildIndex(this.textBox_CMD, 0);
            this.Controls.SetChildIndex(this.textBox_DocType, 0);
            this.Controls.SetChildIndex(this.button_ResetLabels, 0);
            this.Controls.SetChildIndex(this.button_ResetCMD, 0);
            this._panel2_LeftControlPanel.ResumeLayout(false);
            this.panel_TopPanel.ResumeLayout(false);
            this.panel_TopPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RightLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LeftLogo)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Label label_0;
        protected System.Windows.Forms.TextBox textBox5;
        protected System.Windows.Forms.Label label_4;
        protected System.Windows.Forms.Label label_3;
        protected System.Windows.Forms.Label label_2;
        protected System.Windows.Forms.Label label_10;
        protected System.Windows.Forms.Label label11;
        protected System.Windows.Forms.ComboBox comboBox1;
        protected System.Windows.Forms.Label label_1;
        protected System.Windows.Forms.ComboBox comboBox2;
        protected System.Windows.Forms.TextBox textBox_CMD;
        protected System.Windows.Forms.TextBox textBox0;
        protected System.Windows.Forms.TextBox textBox_TableName;
        protected System.Windows.Forms.TextBox textBox_EntityType;
        protected System.Windows.Forms.TextBox textBox_EntityName;
        protected System.Windows.Forms.Button button_DisplayEntity;
        protected System.Windows.Forms.TextBox textBox8;
        protected System.Windows.Forms.TextBox textBox7;
        protected System.Windows.Forms.TextBox textBox6;
        protected System.Windows.Forms.TextBox textBox4;
        protected System.Windows.Forms.TextBox textBox3;
        protected System.Windows.Forms.TextBox textBox2;
        protected System.Windows.Forms.TextBox textBox10;
        protected System.Windows.Forms.TextBox textBox9;
        protected System.Windows.Forms.Button button_Edit;
        protected System.Windows.Forms.TextBox textBox12;
        protected System.Windows.Forms.TextBox textBox11;
        protected System.Windows.Forms.TextBox textBox_13;
        protected System.Windows.Forms.Panel panel3;
        protected System.Windows.Forms.Label label_8;
        protected System.Windows.Forms.Label label_7;
        protected System.Windows.Forms.TextBox textBox_Comment;
        protected System.Windows.Forms.TextBox textBox15;
        protected System.Windows.Forms.TextBox textBox14;
        protected System.Windows.Forms.Label label_12;
        protected System.Windows.Forms.TextBox textBox_DocType;
        protected System.Windows.Forms.Label label12;
        protected System.Windows.Forms.Label label_6;
        protected System.Windows.Forms.Label label_16;
        protected System.Windows.Forms.Label label_14;
        private System.Windows.Forms.Label label_13;
        private System.Windows.Forms.Label label_9;
        protected System.Windows.Forms.Label label_5;
        protected System.Windows.Forms.Button button_ResetLabels;
        protected System.Windows.Forms.Button button_ResetCMD;
        protected System.Windows.Forms.Label label_15;
        protected System.Windows.Forms.Label label_11;


    }
}