﻿    partial class HAWK_Template_3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_CMD = new System.Windows.Forms.TextBox();
            this.button_Display = new System.Windows.Forms.Button();
            this.textBox_TableName = new System.Windows.Forms.TextBox();
            this.comboBox_TableName = new System.Windows.Forms.ComboBox();
            this.label_TableName = new System.Windows.Forms.Label();
            this.textBox_ExternalRef = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label_3 = new System.Windows.Forms.Label();
            this.textBox_InternalRef = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button_Reset = new System.Windows.Forms.Button();
            this._panel2_LeftControlPanel.SuspendLayout();
            this.panel_TopPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RightLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LeftLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // button_ListObjects
            // 
            this.button_ListObjects.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(144)))), ((int)(((byte)(255)))));
            // 
            // button_DisplaySelectedObject
            // 
            this.button_DisplaySelectedObject.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(144)))), ((int)(((byte)(255)))));
            this.button_DisplaySelectedObject.Click += new System.EventHandler(this.button_DisplaySelectedObject_Click);
            // 
            // button_List
            // 
            this.button_List.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            // 
            // button_Change
            // 
            this.button_Change.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            // 
            // button_DisplaySelected
            // 
            this.button_DisplaySelected.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            // 
            // button_SearchData
            // 
            this.button_SearchData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            // 
            // button_Return
            // 
            this.button_Return.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            // 
            // textBox_CMD
            // 
            this.textBox_CMD.Location = new System.Drawing.Point(652, 143);
            this.textBox_CMD.Multiline = true;
            this.textBox_CMD.Name = "textBox_CMD";
            this.textBox_CMD.Size = new System.Drawing.Size(504, 45);
            this.textBox_CMD.TabIndex = 5;
            this.textBox_CMD.Text = "select * from ";
            // 
            // button_Display
            // 
            this.button_Display.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Display.Location = new System.Drawing.Point(690, 200);
            this.button_Display.Name = "button_Display";
            this.button_Display.Size = new System.Drawing.Size(118, 52);
            this.button_Display.TabIndex = 11;
            this.button_Display.Text = "Display";
            this.button_Display.UseVisualStyleBackColor = false;
            // 
            // textBox_TableName
            // 
            this.textBox_TableName.Location = new System.Drawing.Point(521, 160);
            this.textBox_TableName.Name = "textBox_TableName";
            this.textBox_TableName.Size = new System.Drawing.Size(114, 20);
            this.textBox_TableName.TabIndex = 10;
            // 
            // comboBox_TableName
            // 
            this.comboBox_TableName.FormattingEnabled = true;
            this.comboBox_TableName.Location = new System.Drawing.Point(292, 157);
            this.comboBox_TableName.Name = "comboBox_TableName";
            this.comboBox_TableName.Size = new System.Drawing.Size(198, 21);
            this.comboBox_TableName.TabIndex = 9;
            // 
            // label_TableName
            // 
            this.label_TableName.AutoSize = true;
            this.label_TableName.Location = new System.Drawing.Point(201, 165);
            this.label_TableName.Name = "label_TableName";
            this.label_TableName.Size = new System.Drawing.Size(65, 13);
            this.label_TableName.TabIndex = 8;
            this.label_TableName.Text = "Table Name";
            // 
            // textBox_ExternalRef
            // 
            this.textBox_ExternalRef.Location = new System.Drawing.Point(521, 197);
            this.textBox_ExternalRef.Name = "textBox_ExternalRef";
            this.textBox_ExternalRef.Size = new System.Drawing.Size(112, 20);
            this.textBox_ExternalRef.TabIndex = 14;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(290, 192);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 21);
            this.comboBox1.TabIndex = 13;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label_3
            // 
            this.label_3.AutoSize = true;
            this.label_3.Location = new System.Drawing.Point(200, 200);
            this.label_3.Name = "label_3";
            this.label_3.Size = new System.Drawing.Size(57, 13);
            this.label_3.TabIndex = 12;
            this.label_3.Text = "Doc. Type";
            // 
            // textBox_InternalRef
            // 
            this.textBox_InternalRef.Location = new System.Drawing.Point(521, 226);
            this.textBox_InternalRef.Name = "textBox_InternalRef";
            this.textBox_InternalRef.Size = new System.Drawing.Size(112, 20);
            this.textBox_InternalRef.TabIndex = 17;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(290, 224);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(200, 21);
            this.comboBox2.TabIndex = 16;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(200, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "External Ref.";
            // 
            // button_Reset
            // 
            this.button_Reset.Location = new System.Drawing.Point(864, 211);
            this.button_Reset.Name = "button_Reset";
            this.button_Reset.Size = new System.Drawing.Size(97, 41);
            this.button_Reset.TabIndex = 18;
            this.button_Reset.Text = "Reset command";
            this.button_Reset.UseVisualStyleBackColor = true;
            this.button_Reset.Click += new System.EventHandler(this.button_Reset_Click);
            // 
            // HAWK_Template_3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1168, 650);
            this.Controls.Add(this.button_Reset);
            this.Controls.Add(this.textBox_InternalRef);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_ExternalRef);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label_3);
            this.Controls.Add(this.textBox_TableName);
            this.Controls.Add(this.comboBox_TableName);
            this.Controls.Add(this.label_TableName);
            this.Controls.Add(this.button_Display);
            this.Controls.Add(this.textBox_CMD);
            this.Name = "HAWK_Template_3";
            this.Text = "List of Transactions";
            this.Controls.SetChildIndex(this.panel_TopPanel, 0);
            this.Controls.SetChildIndex(this._panel2_LeftControlPanel, 0);
            this.Controls.SetChildIndex(this.textBox_CMD, 0);
            this.Controls.SetChildIndex(this.button_Display, 0);
            this.Controls.SetChildIndex(this.label_TableName, 0);
            this.Controls.SetChildIndex(this.comboBox_TableName, 0);
            this.Controls.SetChildIndex(this.textBox_TableName, 0);
            this.Controls.SetChildIndex(this.label_3, 0);
            this.Controls.SetChildIndex(this.comboBox1, 0);
            this.Controls.SetChildIndex(this.textBox_ExternalRef, 0);
            this.Controls.SetChildIndex(this.label1, 0);
            this.Controls.SetChildIndex(this.comboBox2, 0);
            this.Controls.SetChildIndex(this.textBox_InternalRef, 0);
            this.Controls.SetChildIndex(this.button_Reset, 0);
            this._panel2_LeftControlPanel.ResumeLayout(false);
            this.panel_TopPanel.ResumeLayout(false);
            this.panel_TopPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_RightLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_LeftLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_TableName;
        protected System.Windows.Forms.TextBox textBox_CMD;
        protected System.Windows.Forms.TextBox textBox_TableName;
        protected System.Windows.Forms.ComboBox comboBox_TableName;
        protected System.Windows.Forms.TextBox textBox_ExternalRef;
        protected System.Windows.Forms.ComboBox comboBox1;
        protected System.Windows.Forms.Label label_3;
        protected System.Windows.Forms.TextBox textBox_InternalRef;
        protected System.Windows.Forms.ComboBox comboBox2;
        protected System.Windows.Forms.Label label1;
        protected System.Windows.Forms.Button button_Display;
        protected System.Windows.Forms.Button button_Reset;
    }
